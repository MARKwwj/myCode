package Excel

import (
	"fmt"
	"testing"
)

func TestExcel_ReadAll(t *testing.T) {
	excel := NewExcel(100)
	err := excel.ReadAll("/Users/a77/Documents/workspace/myExcel/apiDetail.xlsx")
	if err != nil {
		fmt.Println(err)
	}
	for _, v := range excel.Rows {
		fmt.Printf("Rows:%#v \n", v)
	}
}
