package Excel

import (
	"fmt"
	"github.com/360EntSecGroup-Skylar/excelize"
	"strconv"
)

//type ExcIn interface {
//	ReadAll(FilePath string) (err error)
//	WriteCol() (err error)
//	AlterCol() (err error)
//}
type Row struct {
	ID     int
	Method string
	Name   string
	Target string
	Url    string
	Body   string
	Resp   string
}
type Excel struct {
	FilePath  string
	SheetName string
	Rows      map[int]*Row
}

func NewExcel(FilePath, SheetName string, size int) *Excel {
	return &Excel{
		FilePath,
		SheetName,
		make(map[int]*Row, size),
	}
}

func (e *Excel) ReadAll() (err error) {
	f, err := excelize.OpenFile(e.FilePath)
	if err != nil {
		fmt.Println(err)
		return
	}
	// Get value from cell by given worksheet name and axis.
	//cell := f.GetCellValue("Sheet1", "B2")
	//fmt.Println(cell)

	// Get all the rows in the Sheet1.
	rows := f.GetRows(e.SheetName)
	for i, row := range rows {
		if i == 0 {
			continue
		}
		rw := &Row{}
		for idx, colCell := range row {
			value := colCell
			switch idx {
			case 0:
				id, err := strconv.Atoi(value)
				if err != nil {
					err = fmt.Errorf("strconv.Atoi(value) failed,err:%v", err)
					return err
				}
				rw.ID = id
			case 1:
				rw.Method = value
			case 2:
				rw.Name = value
			case 3:
				rw.Target = value
			case 4:
				rw.Url = value
			case 5:
				rw.Body = value
			case 6:
				rw.Resp = value
			}
		}
		e.Rows[rw.ID] = rw
	}
	//fmt.Printf("Rows:%#v", e.Rows[2])
	return
}

func (e *Excel) ReadCol() (err error) {
	return err

}

func (e *Excel) WriteCol() (err error) {
	return err

}

func (e *Excel) AlterCol() (err error) {
	return err

}
