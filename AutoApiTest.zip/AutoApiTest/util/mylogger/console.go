package mylogger

import (
	"fmt"
	"time"
)

//构造函数
func NewLogger(lev string) *consoleLogger {
	level, err := parseLogLevel(lev)
	if err != nil {
		panic(err)
	}
	return &consoleLogger{
		level,
	}
}

func (c consoleLogger) enable(level LogLevel) bool {
	return level >= c.level
}
func (c consoleLogger) log(level LogLevel, format string, a ...interface{}) {
	msg := fmt.Sprintf(format, a...)
	if c.enable(level) {
		now := time.Now().Format("2006-01-02 15:04:05")
		funcName, fileName, lineNo := getExecuteFuncInfo(3)
		fmt.Printf("[%s] [%s] [%s:%s:%d] %s \n", now, reverseParseLogLevel(level), funcName, fileName, lineNo, msg)
	}
}

func (c consoleLogger) Debug(format string, a ...interface{}) {
	c.log(Debug, format, a...)
}
func (c consoleLogger) Info(format string, a ...interface{}) {
	c.log(Info, format, a...)
}
func (c consoleLogger) Warning(format string, a ...interface{}) {
	c.log(Warning, format, a...)
}
func (c consoleLogger) Error(format string, a ...interface{}) {
	c.log(Error, format, a...)
}
func (c consoleLogger) Fatal(format string, a ...interface{}) {
	c.log(Fatal, format, a...)
}
