package mylogger

import (
	"fmt"
	"os"
	"path"
	"time"
)

//日志输出到文件
//构造函数
func NewFileLogger(lev, filePath, fileName string, MaxFilesize int64) *FileLogger {
	level, err := parseLogLevel(lev)
	if err != nil {
		panic(err)
	}
	f := &FileLogger{
		level:       level,
		filePath:    filePath,
		fileName:    fileName,
		maxFileSize: MaxFilesize,
	}
	//按照文件路径先将文件打开
	err = f.initFile()
	if err != nil {
		panic(err)
	}
	return f
}

func (f *FileLogger) initFile() error {
	wholeFilePath := path.Join(f.filePath, f.fileName)
	fileObj, err := os.OpenFile(wholeFilePath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		fmt.Println("file openFile failed! err:", err)
		return err
	}
	f.fileObj = fileObj
	errFileObj, err := os.OpenFile(wholeFilePath+".err", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		fmt.Println("file openFile failed! err:", err)
		return err
	}
	f.errFileObj = errFileObj
	return nil

}
func (f *FileLogger) enable(level LogLevel) bool {
	return level >= f.level
}
func (f *FileLogger) fileSplit(curFileObj *os.File) (*os.File, error) {
	fileInfo, err := curFileObj.Stat()
	if err != nil {
		fmt.Println("file get info failed! err:", err)
		return nil, err
	}
	if fileInfo.Size() >= f.maxFileSize {
		timeStr := time.Now().Format("20060102150405000")
		oldFileName := path.Join(curFileObj.Name())
		newFileName := path.Join(curFileObj.Name() + ".bak" + timeStr)
		curFileObj.Close()
		os.Rename(oldFileName, newFileName)
		fileObj, err := os.OpenFile(oldFileName, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			fmt.Println("open new log file failed! err:", err)
			return nil, err
		}
		return fileObj, nil
	}
	return curFileObj, nil
}

func (f *FileLogger) log(level LogLevel, format string, a ...interface{}) {
	msg := fmt.Sprintf(format, a...)
	if f.enable(level) {
		now := time.Now().Format("2006-01-02 15:04:05")
		funcName, fileName, lineNo := getExecuteFuncInfo(3)
		newFileObj, err := f.fileSplit(f.fileObj)
		if err != nil {
			fmt.Println("fileSplit failed! err:", err)
			return
		}
		f.fileObj = newFileObj
		fmt.Fprintf(f.fileObj, "[%s] [%s] [%s:%s:%d] %s \n", now, reverseParseLogLevel(level), funcName, fileName, lineNo, msg)
		if level >= Error {
			newFileObj, err := f.fileSplit(f.errFileObj)
			if err != nil {
				fmt.Println("errFileSplit failed! err:", err)
				return
			}
			f.errFileObj = newFileObj
			fmt.Fprintf(f.errFileObj, "[%s] [%s] [%s:%s:%d] %s \n", now, reverseParseLogLevel(level), funcName, fileName, lineNo, msg)
		}
	}
}

func (f *FileLogger) Debug(format string, a ...interface{}) {
	f.log(Debug, format, a...)
}
func (f *FileLogger) Info(format string, a ...interface{}) {
	f.log(Info, format, a...)
}
func (f *FileLogger) Warning(format string, a ...interface{}) {
	f.log(Warning, format, a...)
}
func (f *FileLogger) Error(format string, a ...interface{}) {
	f.log(Error, format, a...)
}
func (f *FileLogger) Fatal(format string, a ...interface{}) {
	f.log(Fatal, format, a...)
}
func (f *FileLogger) closeFile() {
	f.fileObj.Close()
	f.errFileObj.Close()
}
