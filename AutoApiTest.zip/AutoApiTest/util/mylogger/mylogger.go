package mylogger

import (
	"errors"
	"fmt"
	"os"
	"path"
	"runtime"
	"strings"
)

//定义一个日志级别的类型
type LogLevel uint8

//日志等级
const (
	UNKNOWN LogLevel = iota //0
	Debug
	Info
	Warning
	Error
	Fatal
)

//日志接口
type Logger interface {
	Debug(format string, a ...interface{})
	Info(format string, a ...interface{})
	Warning(format string, a ...interface{})
	Error(format string, a ...interface{})
	Fatal(format string, a ...interface{})
}

//往终端写日志
type consoleLogger struct {
	level LogLevel
}

//往文件写日志
type FileLogger struct {
	level       LogLevel
	filePath    string
	fileName    string
	fileObj     *os.File
	errFileObj  *os.File
	maxFileSize int64
}

// level 转为对应常量
func parseLogLevel(s string) (LogLevel, error) {
	s = strings.ToLower(s)
	switch s {
	case "debug":
		return Debug, nil
	case "info":
		return Info, nil
	case "warning":
		return Warning, nil
	case "error":
		return Error, nil
	case "fatal":
		return Fatal, nil
	default:
		err := errors.New("unknown type")
		return UNKNOWN, err
	}
}

//反向解析 level 即 转为string
func reverseParseLogLevel(level LogLevel) string {
	switch level {
	case Debug:
		return "debug"
	case Info:
		return "info"
	case Warning:
		return "warning"
	case Error:
		return "error"
	case Fatal:
		return "fatal"
	default:
		return "debug"
	}
}

//获取调用了打印日志.go文件的信息 函数名 文件名 行号
func getExecuteFuncInfo(skip int) (funcName, fileName string, lineNo int) {
	pc, file, lineNo, ok := runtime.Caller(skip)
	if !ok {
		fmt.Println("runtime.Caller failed!")
		return
	}
	funcNameStr := runtime.FuncForPC(pc).Name()
	funcName = (strings.Split(funcNameStr, "."))[1]
	fileName = path.Base(file)
	return funcName, fileName, lineNo
}
