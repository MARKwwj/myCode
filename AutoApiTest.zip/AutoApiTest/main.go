package main

import (
	"fmt"
	"github.com/satori/go.uuid"
	"gopkg.in/ini.v1"
	"io/ioutil"
	"log"
	"myCode/AutoApiTest/conf"
	"myCode/AutoApiTest/util/Excel"
	"net/http"
	"os"
	"regexp"
	"strings"
)

var (
	cfg = new(conf.Config)
)

type header struct {
	Token       string `json:"x-token"`
	ContentType string `json:"Content-Type"`
}

var contentTp = "application/json"
var token string

func main() {
	if err := ini.MapTo(cfg, "./conf/conf.ini"); err != nil {
		panic(err)
	}
	//设置日志输出位置
	logFileLocation, _ := os.OpenFile(cfg.LogCfg.FilePath, os.O_CREATE|os.O_APPEND|os.O_RDWR, 0744)
	log.SetOutput(logFileLocation)
	login := Excel.NewExcel(cfg.ExcelCfg.FilePath, "login", cfg.ExcelCfg.Size)
	err := login.ReadAll()
	if err != nil {
		log.Printf("login ReadAll failed,err:%v/n", err)
	}
	TestLogin(login)
}

func TestLogin(e *Excel.Excel) {
	row01 := e.Rows[1]
	//logger.Info("row01:%#v", row01)
	u1 := uuid.NewV4()
	resp, err := http.Post(row01.Url, contentTp, strings.NewReader(fmt.Sprintf(row01.Body, u1)))
	if err != nil {
		log.Printf("http post failed,err:%v/n", err)
	}
	defer resp.Body.Close()
	all, err := ioutil.ReadAll(resp.Body)
	log.Printf(fmt.Sprintf(row01.Body, u1))
	//log.Printf(string(all))
	exists := regex(string(all), "成功")
	if exists {

	}
}

func regex(str, sub string) (exists bool) {
	//解析正则表达式，如果成功返回解释器
	reg1 := regexp.MustCompile(sub)
	if reg1 == nil {
		log.Printf("regexp failed/n")
		return
	}
	//根据规则提取关键信息
	result := reg1.FindAllString(str, -1)
	res := fmt.Sprintf("result:%v", result)
	if len(res) == 9 {
		log.Println("regex not exists.")
		exists = false
	} else {
		log.Println(res)
		exists = true
	}
	return
}

