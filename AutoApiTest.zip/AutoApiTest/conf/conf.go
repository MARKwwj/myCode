package conf

type Config struct {
	ExcelCfg `ini:"Excel"`
	LogCfg   `ini:"log"`
}

type ExcelCfg struct {
	FilePath string `ini:"file_path"`
	Size     int    `ini:"size"`
}

type LogCfg struct {
	Level    string `ini:"level"`
	FilePath string `ini:"file_path"`
	FileName string `ini:"file_name"`
	Size     int64  `ini:"size"`
}
