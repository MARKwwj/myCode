create
    definer = root@`%` procedure init_model()
BEGIN
	-- 定义变量
	DECLARE s int DEFAULT 0;
	DECLARE modelId varchar(256);
	DECLARE a int DEFAULT 1;
	-- 定义游标，并将sql结果集赋值到游标中
	DECLARE report CURSOR FOR select model_id from video_model_ref group by model_id ;
	-- 声明当游标遍历完后将标志变量置成某个值
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET s=1;
	-- 打开游标
	open report;
		-- 将游标中的值赋值给变量，注意：变量名不要和返回的列名同名，变量顺序要和sql结果列的顺序一致
		fetch report into modelId;
		-- 当s不等于1，也就是未遍历完时，会一直循环
		while s<>1 do
			-- 执行业务逻辑
			set @rownum=0;
			update video_model_ref
			SET sort = (
			select @rownum := @rownum +1 as nid)
			where model_id = modelId;
			-- 将游标中的值再赋值给变量，供下次循环使用
			fetch report into modelId;
		-- 当s等于1时表明遍历以完成，退出循环
		end while;
	-- 关闭游标
	close report;
END;

